use num::complex::Complex;
use itertools_num::linspace;
use std::io::prelude::*;
use std::net::{TcpStream, TcpListener};



#[derive(Debug)]
pub struct Parameters{
    pub zoom: f64,

    pub low_x: f64,

    pub low_y: f64,

    pub radius_x: f64,
    pub radius_y: f64,

    pub quality: isize,
}

pub fn write_to_file(params: &Parameters) -> String{
	let values = calculate(params);
	values
}

/*
fn talk_to_python() -> std::io::Result<()>{
    let host = "127.0.0.1:";
    let pixel_port = "65432";
    let param_port = "65431";

    let pixel_hostname = host.to_string() + pixel_port;
    let param_hostname = host.to_string() + param_port;
    
    let mut stream = TcpStream::connect(pixel_hostname).expect("run the renderer smh");
    
    println!("i do be listening doe");
    
    loop{
        
         let results = calculate(300.0, -0.5, 0.0, 1.0, 1.0, 510);
        println!("ok just sending the results over now");
        stream.write(&results.as_bytes())?;
        println!( "{:?}", get_params(&param_hostname));
        break;
    }
    Ok(())
}
*/

fn get_params(param_hostname: &str) {
    let listener = TcpListener::bind(param_hostname).unwrap();
    println!("connected");
    let mut stream = match listener.accept() {
        Ok((socket, addr)) => {
            println!("new client: {:?}", addr);
            socket
        }
        Err(e) => {
            println!("couldn't get client: {:?}", e);
            panic!("oh no");
        }
    };
    let mut buf = [0; 32];
    stream.read(&mut buf).expect("error reading the stream");
    println!("{:?}", buf);
}


fn bounded(c: &Complex<f64>, iterations: isize) -> isize{

    let mut z = Complex::new(0.0, 0.0);

    let mut i = 0;
    loop{
        z = (z * z) + c;
        if z.norm() > 100.0 {
            return i;
        }
        if i >= iterations{
            return -1;
        }
        i+=1;
    }
}

fn calculate(parameters: &Parameters) -> String {
    let low_x = parameters.low_x;
    let high_x = low_x + 2.0 * parameters.radius_x;

    let low_y = parameters.low_y;
    let high_y = low_y + 2.0 * parameters.radius_y;
    
    let width = (num::abs(low_x - high_x) * parameters.zoom) as isize;
    let height = (num::abs(low_y - high_y) * parameters.zoom) as isize;

    if width > 2000{panic!("width really big");}
    if height > 2000{panic!("height really big");}

    let reals = linspace::<f64>(low_x,high_x,width.try_into().unwrap());
    let mut results = String::new();
    

    for y in reals{
        let cs = linspace::<f64>(low_y,high_y,height.try_into().unwrap());
        for x in cs{
            let c = Complex::new(x, y);
            
            results = results + &bounded(&c, parameters.quality).to_string();
            results = results + ",";
        }
		results = results + "\n";
    }
    results = results + &width.to_string();
    results = results + ",";
    results = results + &height.to_string();
    results = results + "d";
    results
}
